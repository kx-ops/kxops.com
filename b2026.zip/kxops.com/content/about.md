+++
date = '2026-05-07T10:50:51+08:00'
draft = false
title = 'About me'
+++

## 个人简介
资深 DevOps & SRE 工程师，专注于云原生架构与高性能基础设施优化。

## 技术栈
*   **容器化**: Kubernetes, Docker
*   **GitOps**: Argo CD, GitHub Actions
*   **数据库**: MariaDB, MySQL ,PG
*   **网络**: Cloudflare Zero Trust
